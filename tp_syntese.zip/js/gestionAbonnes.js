"use strict";

const CLE_AUTHENTIFIE = "ABONNE_AUTHENTIFIE";
const CLE_PREFIXE_ABONNE = "ABONNE_";
const idInscription = document.getElementById("indentifiant");
const idAuthentification = document.getElementById("indentifiants");
let estConecte = false;
/*
    Pour les tests, on crée déjà 3 abonnés (hardcoding).
    Éventuellement, les abonnés seront créés par une fonction constructeur.
*/

function initAbonnesDepart() {
    let user = null;
    const valideurAUthentification = document.getElementById('validerAutentification');
    valideurAUthentification.addEventListener("click",function (e) {
        e.preventDefault();
        validerConecter();
    });

    const validateurInscription = document.getElementById('valideurInsription');
    validateurInscription.addEventListener("click",function (e){
        e.preventDefault();
        verificationInputInscription();
        enregistrerAbonne();
    });

    const validateurBoutonDeJeu = document.getElementById('buttonDeJeu');
    validateurBoutonDeJeu.addEventListener("click",function (e){
        e.preventDefault();
        peutJouer();
    })

    if (typeof (localStorage) != "undefined") {
        // Le mot de passe non-crypté de user1 est "Ave Maria".
        user = {nom: "user1", motDePasseCrypte: "f24d1a09990934170bbeeed20ab85758", pseudonyme: "Agathe"};
        localStorage.setItem(CLE_PREFIXE_ABONNE + user.nom, JSON.stringify(user));


        // Le mot de passe non-crypté de user2 est "Banana split".
        user = {nom: "user2", motDePasseCrypte: "8656cc8ebb46e96ab90ad17008d9d870", pseudonyme: "Brenda"};
        localStorage.setItem(CLE_PREFIXE_ABONNE + user.nom, JSON.stringify(user));

        // Le mot de passe non-crypté de user3 est "Casa Loma".
        user = {nom: "user3", motDePasseCrypte: "56628af0d9a167d119068049184246b8", pseudonyme: "Celine"};
        localStorage.setItem(CLE_PREFIXE_ABONNE + user.nom, JSON.stringify(user));
    }
}
function Abonne(nom,pseudo,motDePass) {
    this.nom = nom;
    this.pseudo = pseudo;
    this.motDePass = motDePass;

}

function setAbonner(identifiant, pseudo, motDePass) {
        const nom = document.getElementById(identifiant).value;
        const pseudonyme = document.getElementById(pseudo).value;
        const motDePasse = document.getElementById(motDePass).value;
        const motDePassCrypter =changerMotDePass(motDePasse);
        return new Abonne(nom, pseudonyme, motDePassCrypter);
    }
function setAbonner2 (indentifiant,motDePass) {
        const nom = document.getElementById(indentifiant).value;
        const motdePass = document.getElementById(motDePass).value;
        const motDePassCrypter =changerMotDePass(motdePass);
        const pseud = getPseudo(nom);
        return new Abonne(nom, pseud, motDePassCrypter);
    }
function estAuthentifie (nom) {
        return localStorage.getItem(CLE_PREFIXE_ABONNE + nom) !== null;
    }

function setAuthentifie(abonne) {
        const utilisateurJson = JSON.stringify(abonne);
        localStorage.setItem(CLE_PREFIXE_ABONNE + abonne.nom, utilisateurJson);
        sessionStorage.setItem(CLE_AUTHENTIFIE + abonne.nom, utilisateurJson);
        estConecte = true;
    }
function changerMotDePass(motDePass) {
        return CryptoJS.MD5(motDePass).toString();
    }
function validerNouvelAbonner (chaine) {
        for(let i = 0; i< localStorage.length; i++){
            const cle = localStorage.key(i)
            const chaineComparaison = cle.replace(CLE_PREFIXE_ABONNE, "");
            if(chaine === chaineComparaison){
                return false;
            }
        }
        return true;
    }
function validerMotDePassIdentiques (chaineMdp,chaineCmdp){
        return chaineMdp === chaineCmdp;
    }
function getPseudo(nom) {
    for (let i = 0; i < localStorage.length; i++) {
        const cle = localStorage.key(i);
        if (cle === CLE_PREFIXE_ABONNE+nom) {
            const abonneJson = localStorage.getItem(cle);
            const abonne = JSON.parse(abonneJson);
            return abonne.pseudonyme;
        }
    }
    return null;
}

function creationAbonne(idInputIdentifiant){
    if (idInputIdentifiant === idInscription) {
        return setAbonner('indentifiant', 'pseudo', 'mdp');

    } else if (idInputIdentifiant === idAuthentification) {
        return setAbonner2('indentifiants', 'mdps');
    }
}

function resetPage(){
    const input = document.getElementById("indentifiant");
    const form = document.getElementById("form-inscription");
    form.reset();
    input.focus();
    return false;
}
function peutJouer(){
    if(estConecte === false){
        alert("non connecte")
    }
    else {
        naviguerPage(PAGE_JEU);
    }
}
function enregistrerAbonne(){
    if(typeof(Storage) !== "undefined") {
        let abonne = creationAbonne(idInscription)
        if(validerNouvelAbonner(abonne.nom)) {
            if(verificationInputInscription()){
               alert("bon mot de pass")
                setAuthentifie(abonne);
                naviguerPage(PAGE_JEU);
            }
            else{
                alert("mot de pass pas identique")
                resetPage();
            }
        }
        else{
            alert("Il y a deja un abonne avec l'identifiant " + abonne.nom);
            resetPage();
        }
    }
}
function validerConecter() {
    let abonne = setAbonner2('indentifiants','mdps');
    if (estAuthentifie(abonne.nom)) {
            setAuthentifie(abonne);
            alert("l'abonne " + abonne.nom + " est authentifier");
            naviguerPage(PAGE_JEU);
    } else {
        alert("L'ABONNE " + abonne.nom + " N'EST PAS AUTHENTIFIER");
    }

}

function verificationInputInscription(){
    let abonne2 = setAbonner('indentifiant','pseudo','mdp');
    const motDePassConfiramtion = document.getElementById("cmdp").value;
    const nouveauMDP =changerMotDePass(motDePassConfiramtion);
    return      validerMotDePassIdentiques(abonne2.motDePass,nouveauMDP) === true;
}


